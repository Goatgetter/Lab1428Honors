#include <iostream>
#include <cmath>
#include <fstream>
// Programmer: Ross Strickland rcs114 cs1428
// Use: emulating assembly code
using namespace std;

int main()
{
    ifstream fin;
    fin.open("instruct.txt");
    if(!fin)
        cout << "File could not be opened.";
    int RAM[256];
    int prefrontal[4];
    int linenumber;
    cout << "The number of lines of code is "; fin >> linenumber;
    cout << linenumber<<endl;
    for(int j=0;j<linenumber;j++){
    for(int i=0;i<4;i++)
    {
        fin >> prefrontal[i]; // operation, location,
    }
    cout << "The code in this line is "<<prefrontal[0]<<" "<<prefrontal[1]<<" "<<prefrontal[2]<<" "<<prefrontal[3]<<endl;
    switch(prefrontal[0])
    {
        case 0: RAM[prefrontal[1]]=RAM[prefrontal[2]]+RAM[prefrontal[3]]; //calculation
        break;
        case 1: RAM[prefrontal[1]]=RAM[prefrontal[2]]-RAM[prefrontal[3]];
        break;
        case 2: RAM[prefrontal[1]]=RAM[prefrontal[2]]*RAM[prefrontal[3]];
        break;
        case 3: RAM[prefrontal[1]]=RAM[prefrontal[2]]/RAM[prefrontal[3]];
        break;
        case 4: RAM[prefrontal[1]]=RAM[prefrontal[2]]%RAM[prefrontal[3]];
        break;
        case 5: RAM[prefrontal[1]] = prefrontal[2]; //reads in a new value into RAM
        break;
        case 6: cout <<"The Value Returned is "<< RAM[prefrontal[1]]; //prints out a value from RAM
        break;
        case 7: RAM[prefrontal[1]]=RAM[prefrontal[2]]; //assigns one value from RAM to another value in RAM
        break;
        default: cout <<"Unable to perform operation"; //error catch
    }

    }
    return 0;

}
